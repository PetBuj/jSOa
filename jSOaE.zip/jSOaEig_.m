%Bujok, 2024

function BestData = jSOaEig_(MaxEval, e2s)
% Run Information
ErrorToStop = e2s;

Ap = 0.2;
N_min = 4;
ps = 0.5;
peig = 0.4;

% Tension/compression spring design
nDim = 3;
LB = [0.05, 0.25, 2.00];
UB = [2, 1.3, 15.0];
VioFactor = [3 4 0.1 0.1 1];
Obj = @compressProblem;
GloMin = 0.012665232788;

LB = LB.*ones(1,nDim);
UB = UB.*ones(1,nDim);

if nDim < 6
    N_init = round(25 * log(6) * sqrt(6)); 
else
    N_init = round(25 * log(nDim) * sqrt(nDim));
end
if N_init < 2 * N_min
    N_init = 2* N_min;
end
nPop = N_init;
Asize_max = round(nPop * 2.6); %1 - 3
H = 5; %2 - 10


% Cost Function
Cost = @(x) CostFunction(x, VioFactor, Obj);

% Initialization
x = nan(nPop,nDim);
z = nan(nPop, 1);

emptyData.z = [];
emptyData.f = [];
emptyData.g = [];
emptyData.v = [];
emptyData.x = [];
Data = repmat(emptyData, nPop, 1);

% A memory for counting number of function evaluations


for i = 1:nPop
    x(i,:) = LB + rand(1,nDim).*(UB - LB);
    [z(i), Data(i)] = Cost(x(i,:));
end
neval = nPop;

MF = 0.3 * ones(1, H);
MCR = 0.8 * ones(1, H);
MF(H) = 0.9;
MCR(H) = 0.9;
k = 1;
Asize = 0;
A = [];

pmax = 0.25; 
pmin = pmax / 2;

% Main Loop
while neval < MaxEval
    Fpole = -1 * ones(1, nPop);
    CRpole = -1 * ones(1, nPop);
    SCR = [];
    SF = [];
    suc = 0;
    deltafce = -1 * ones(1, nPop);
    pp = pmax - ((pmax - pmin) * (neval / MaxEval));
    
    if rand < peig % eig. cross will be used for whole pop.
        P = [x z];
        Popeig = sortrows(P, nDim + 1);
        if round(nPop * ps + 1) >= 3
            Popeig(round(nPop * ps + 1):nPop, :) = [];
        end
        [EigVect, ~] = eig(cov(Popeig(:, 1:nDim)));
        
        for i = 1:nPop
            
            r = nahvyb(H, 1);
            CR = MCR(1, r) + sqrt(0.1) * randn(1);
            if CR > 1
                CR = 1;
            elseif CR < 0
                CR = 0;
            end
            % jSO CR:
            if neval < (0.25 * MaxEval)
                CR = max([CR 0.7]);
            elseif neval < (0.5 * MaxEval)
                CR = max([CR 0.6]);
            end
            F = -1;
            while F <= 0
                F = rand * pi - pi / 2;
                F = 0.1 * tan(F) + MF(1, r);
            end
            if F > 1
                F = 1;
            end
            %jSO F:
            if (neval < (0.6 * MaxEval)) && (F > 0.7)
                F = 0.7;
            end
            Fpole(i) = F;
            CRpole(i) = CR;
            %cur.solution
            nx = x(i, :);
            expt = i;
            p = max(2, ceil(pp * nPop));
            [~, xorder] = sortrows(z);
            pom = x(xorder, :); %sort pop based on func.values
            pbest = pom(1:p, 1:nDim);
            ktery = 1 + fix(p * rand(1));
            xpbest = pbest(ktery, :);
            vyb = nahvyb_expt(nPop, 1, expt);
            r1 = x(vyb, 1:nDim);
            expt = [expt, vyb];
            vyb = nahvyb_expt(nPop + Asize, 1, expt);
            sjed = [[x(:, 1:nDim) z]; A];
            r2 = sjed(vyb, 1:nDim);
            if neval < 0.2 * MaxEval
                Fw = 0.7 * F;
            elseif neval < 0.4 * MaxEval
                Fw = 0.8 * F;
            else
                Fw = 1.2 * F;
            end
            
            v = nx + Fw * (xpbest - nx) + F * (r1 - r2);
            
            nxeig = EigVect' * nx';
            veig = EigVect' * v';
            
            change = find(rand(1, nDim) < CR);
            if isempty(change) % at least one element is changed
                change = 1 + fix(nDim * rand(1));
            end
            nxeig(change) = veig(change);
            nx = (EigVect * nxeig)';
            
            zrc = find(nx < LB | nx > UB);
            for ii = zrc
                while (nx(ii) < LB(ii) || nx(ii) > UB(ii))
                    if nx(ii) > UB(ii)
                        nx(ii) = 2 * UB(ii) - nx(ii);
                    elseif nx(ii) < LB(ii)
                        nx(ii) = 2 * LB(ii) - nx(ii);
                    end
                end
            end
            
            % Evaluation
            [nz, nData] = Cost(nx);
            neval = neval + 1;
            
            if nz < z(i)
                deltafce(i) = z(i) - nz;
                z(i) = nz;
                x(i,:) = nx;
                Data(i) = nData;
                suc = suc + 1;
                if Asize < Asize_max
                    A = [A; [x(1:nDim) z(i)]];
                    Asize = Asize + 1;
                else
                    A = sortrows(A, nDim + 1);
                    %replace only elements worse than median (func.value)
                    ah = ceil(Asize * (1 - Ap));
                    ktere = ah + nahvyb(Asize - ah, 1);
                    A(ktere, :) = [x(i, 1:nDim) z(i)];
                end
                SCR = [SCR, CRpole(1, i)];
                SF = [SF, Fpole(1, i)];
            end
            
            
            if suc > 0
                MCR_old = MCR(1, k);
                MF_old = MF(1, k);
                platne = find(deltafce ~= -1);
                delty = deltafce(1, platne);
                sum_delta = sum(delty);
                vahyw = 1 / sum_delta * delty;
                mSCR = max(SCR);
                if (MCR(1, k) == -1) || (mSCR == 0)
                    MCR(1, k) = -1;
                else
                    meanSCRpomjm = vahyw .* SCR;
                    meanSCRpomci = meanSCRpomjm .* SCR;
                    MCR(1, k) = sum(meanSCRpomci) / sum(meanSCRpomjm);
                end
                meanSFpomjm = vahyw .* SF;
                meanSFpomci = meanSFpomjm .* SF;
                MF(1, k) = sum(meanSFpomci) / sum(meanSFpomjm);
                MCR(1, k) = (MCR(1, k) + MCR_old) / 2;
                MF(1, k) = (MF(1, k) + MF_old) / 2;
                k = k + 1;
                if k >= H
                    k = 1;
                end
            end
        end
    else        
        for i = 1:nPop
            
            r = nahvyb(H, 1);%        r=1+fix(H*rand(1));
            CR = MCR(1, r) + sqrt(0.1) * randn(1);
            if CR > 1
                CR = 1;
            elseif CR < 0
                CR = 0;
            end
            % jSO CR:
            if neval < (0.25 * MaxEval)
                CR = max([CR 0.7]);
            elseif neval < (0.5 * MaxEval)
                CR = max([CR 0.6]);
            end
            F = -1;
            while F <= 0
                F = rand * pi - pi / 2;
                F = 0.1 * tan(F) + MF(1, r);
            end
            if F > 1
                F = 1;
            end
            %jSO F:
            if (neval < (0.6 * MaxEval)) && (F > 0.7)
                F = 0.7;
            end
            Fpole(i) = F;
            CRpole(i) = CR;
            %cur.solution
            nx = x(i, :);
            expt = i;
            p = max(2, ceil(pp * nPop));
            [~, xorder] = sortrows(z);
            pom = x(xorder, :); %sort pop based on func.values
            pbest = pom(1:p, 1:nDim);
            ktery = 1 + fix(p * rand(1));
            xpbest = pbest(ktery, :);
            vyb = nahvyb_expt(nPop, 1, expt);
            r1 = x(vyb, 1:nDim);
            expt = [expt, vyb];
            vyb = nahvyb_expt(nPop + Asize, 1, expt);
            sjed = [[x(:, 1:nDim) z]; A];
            r2 = sjed(vyb, 1:nDim);
            if neval < 0.2 * MaxEval
                Fw = 0.7 * F;
            elseif neval < 0.4 * MaxEval
                Fw = 0.8 * F;
            else
                Fw = 1.2 * F;
            end
            v = x(i, 1:nDim) + Fw * (xpbest - x(i, 1:nDim)) + F * (r1 - r2);
            change = find(rand(1, nDim) < CR);
            if isempty(change) % at least one element is changed
                change = 1 + fix(nDim * rand(1));
            end
            nx(change) = v(change);
            zrc = find(nx < LB | nx > UB);
            for ii = zrc
                while (nx(ii) < LB(ii) || nx(ii) > UB(ii))
                    if nx(ii) > UB(ii)
                        nx(ii) = 2 * UB(ii) - nx(ii);
                    elseif nx(ii) < LB(ii)
                        nx(ii) = 2 * LB(ii) - nx(ii);
                    end
                end
            end
            
            % Evaluation
            [nz, nData] = Cost(nx);
            neval = neval + 1;
            
            if nz < z(i)
                deltafce(i) = z(i) - nz;
                z(i) = nz;
                x(i,:) = nx;
                Data(i) = nData;
                suc = suc + 1;
                if Asize < Asize_max
                    A = [A; [x(1:nDim) z(i)]];
                    Asize = Asize + 1;
                else
                    A = sortrows(A, nDim + 1);
                    %replace only elements worse than median (func.value)
                    ah = ceil(Asize * (1 - Ap));
                    ktere = ah + nahvyb(Asize - ah, 1);
                    A(ktere, :) = [x(i, 1:nDim) z(i)];
                end
                SCR = [SCR, CRpole(1, i)];
                SF = [SF, Fpole(1, i)];
            end
            
            
            if suc > 0
                MCR_old = MCR(1, k);
                MF_old = MF(1, k);
                platne = find(deltafce ~= -1);
                delty = deltafce(1, platne);
                sum_delta = sum(delty);
                vahyw = 1 / sum_delta * delty;
                mSCR = max(SCR);
                if (MCR(1, k) == -1) || (mSCR == 0)
                    MCR(1, k) = -1;
                else
                    meanSCRpomjm = vahyw .* SCR;
                    meanSCRpomci = meanSCRpomjm .* SCR;
                    MCR(1, k) = sum(meanSCRpomci) / sum(meanSCRpomjm);
                end
                meanSFpomjm = vahyw .* SF;
                meanSFpomci = meanSFpomjm .* SF;
                MF(1, k) = sum(meanSFpomci) / sum(meanSFpomjm);
                MCR(1, k) = (MCR(1, k) + MCR_old) / 2;
                MF(1, k) = (MF(1, k) + MF_old) / 2;
                k = k + 1;
                if k >= H
                    k = 1;
                end
            end
        end
    end
    
    % Update Best Solution
    [zBest, BestIndex] = min(z);
    BestData = Data(BestIndex);
            
    N_old = nPop;
    nPop = round(((N_min - N_init) / MaxEval) * neval + N_init);
    if nPop < N_old
        [z, xorder] = sortrows(z);
        x = x(xorder, :); %sort pop based on func.values
        x(nPop + 1:end, :) = [];
        z(nPop + 1:end, :) = [];
        Asize_max = round(nPop * 2.6);
        while Asize > Asize_max
            index_v_arch = nahvyb(Asize, 1);
            A(index_v_arch, :) = [];
            Asize = Asize - 1;
        end
    end
    
    % Stop Algorithm
    if zBest <= GloMin + ErrorToStop
        zBest = GloMin;
        BestData.z = zBest;
        break
    end
end
BestData.stage = zBest;
end