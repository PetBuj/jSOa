clc; clear; close all;
%Tension/compression spring design
%% Run Information
nRun = 31;                      % Number of runs
e2s = 1e-8;                     % Erorr to stop
MaxEval=9000;%*ones(1,13);        % Maximum NFEs for each problem



%% Run algorithm
for Run = 1:nRun
    % Run SNS
    bla = jSOaEig_(MaxEval,e2s);
    % Run step
    clc;
    
    disp(['Run : ' num2str(Run)])
    disp(bla.z)
end


